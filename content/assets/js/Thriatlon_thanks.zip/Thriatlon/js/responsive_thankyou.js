// $( window ).resize(function() {
// 	if($( window ).width()<=1290){
// 		$( "#copyright" ).attr( "class", function(){ return "left col-md-offset-1 col-md-4"} ) ;
// 	} else {
// 		$( "#copyright" ).attr( "class", function(){ return "left col-md-offset-2 col-md-3"} ) ;
// 	}
// });

// $( window ).resize(function() {
// 	if($( window ).width()<=1120){
// 		$( "#footer_menu" ).attr( "class", function(){ return "right col-md-3 col-md-offset-4"} ) ;
// 	} else {
// 		$( "#footer_menu" ).attr( "class", function(){ return "right col-md-4 col-md-offset-3"} ) ;
// 	}
// });

// $( window ).resize(function() {
// 	console.log($( document ).width());
// 	if($( window ).width()<=1115){
// 		$( "#footer_menu" ).attr( "class", function(){ return "right col-md-2 col-md-offset-5"} ) ;
// 	} else {
// 		$( "#footer_menu" ).attr( "class", function(){ return "right col-md-3 col-md-offset-4"} ) ;
// 	}
// });